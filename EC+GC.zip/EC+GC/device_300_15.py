import ipkiss3.all as i3                    # i3 is an alias for ipkiss3.all
import asp_sin_lnoi_photonics.all as asp
from asp_sin_lnoi_photonics.components.waveguides.rib.trace_780nm import RWG600_780nm, SiNRibWaveguideTemplate_780nm
import numpy as np
import matplotlib.pyplot as plt
from cell import GRATING_COUPLER_TE780_RIBY
from EC_300_15 import Structure_300_15
ec = Structure_300_15()


class EC300_15(i3.PCell):
    structure_long = i3.ChildCellProperty(locked=True, doc="the waveguide")
    grating_coupler = i3.ChildCellProperty(locked=True, doc="grating")

    def _default_structure_long(self):
        return Structure_300_15()

    def _default_grating_coupler(self):
        return GRATING_COUPLER_TE780_RIBY()

    class Layout(i3.LayoutView):
        def _default_structure_long(self):
            structure_long_layout = self.cell.structure_long.get_default_view(i3.LayoutView)
            return structure_long_layout

        def _default_grating_coupler(self):
            gc_layout = self.cell.grating_coupler.get_default_view(i3.LayoutView)
            return gc_layout

        def _generate_instances(self, insts):
            insts += i3.SRef(name='structure_long', reference=self.cell.structure_long)
            insts += i3.SRef(name="gc_in", reference=self.cell.grating_coupler)
            insts += i3.SRef(name="gc_out", reference=self.cell.grating_coupler)

            return i3.place_and_route(
                insts=insts,
                specs=[
                    i3.Place("structure_long", (0, 0)),
                    i3.Place("gc_in", (-200, 0), angle=0, relative_to="structure_long:in"),
                    i3.Place("gc_out", (200, 0), angle=180, relative_to="structure_long:out"),
                    i3.ConnectBend("gc_in:out", "structure_long:in"),
                    i3.ConnectBend("gc_out:out", "structure_long:out"),
                ]
            )


ring_test_layout = EC300_15().Layout()
ring_test_layout.visualize(annotate=True)
ring_test_layout.write_gdsii("grating-EC.gds")