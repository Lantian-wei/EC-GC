import ipkiss3.all as i3                    # i3 is an alias for ipkiss3.all
import asp_sin_lnoi_photonics.all as asp
from asp_sin_lnoi_photonics.components.waveguides.rib.trace_780nm import RWG600_780nm, SiNRibWaveguideTemplate_780nm
import numpy as np
import matplotlib.pyplot as plt
from scipy.special import erf
from cell import GRATING_COUPLER_TE780_RIBY

#1D LN(ne) Simulation
a=0.003342
b=0.002229
lambda0=780e-9
w=800e-6
EC_width=800
starting_EC=-510
end_EC=3100
EC_length=end_EC-starting_EC
waveguide_width=0.63
waveguide_start=-510
wg_connect=100
waveguide_end=end_EC
Slab_width=800
bend_start = (end_EC, -waveguide_width/2)
bend_end = (waveguide_end+400, -500)
extend=550


def gap(z):
    term1 = 1 / (a / lambda0 * (np.sqrt(2) * np.pi ** 1.5 * w))
    term2 = np.exp(-2 * ((z/w)** 2))
    term3 = 1 - erf(np.sqrt(2) * z / w)
    return -1/b * (np.log(term1) + np.log(term2) - np.log(term3))

z_values = np.linspace(starting_EC*10**-6, end_EC*10**-6, 100)
y_values = gap(z_values)

X=np.array(z_values)*(10**6)
Y = [round(x) *10**-3 for x in y_values]
initial_gap=gap(starting_EC*10**-6)*10**-3
end_gap=gap(end_EC*10**-6)*10**-3
#print(end_gap)
points = list(zip(X, Y))
points.extend([(end_EC+extend,end_gap),(end_EC+extend, EC_width),(starting_EC,EC_width), (starting_EC,initial_gap)])

###individual Slab
class Slab(i3.PCell):
    points = i3.ListProperty( doc="Polygon points for slab")
    class Layout(i3.LayoutView):
        #points = i3.ListProperty(default=points,doc="Polygon points for slab")
        layer = i3.LayerProperty(default=asp.TECH.PPLAYER.RWG.CORE, doc='Layer to drawn on')
        waveguide_cladding_layer = i3.LayerProperty(default=i3.TECH.PPLAYER.RWG.CLADDING,
                                                    doc="the optical waveguide cladding layer")
        def _generate_elements(self, elems):
            polygon = i3.Shape(points)
            elems += i3.Boundary(layer=self.layer, shape=polygon)
            # Expand the SiO2 cladding along the whole area
            elems += i3.Rectangle(self.waveguide_cladding_layer, center=(1295+extend/2, Slab_width/2-5),
                                  box_size=(EC_length+extend, Slab_width+30))
            return elems


###other components
class Structure_300_15(i3.PCell):
    trace_template = i3.TraceTemplateProperty(doc="the trace template for waveguide")
    trace_template_wide = i3.TraceTemplateProperty(doc="the trace template for waveguide")
    waveguide = i3.ChildCellProperty(locked=True, doc="the waveguide")
    slab = i3.ChildCellProperty(locked=True, doc="the slab")
    bend_waveguide=i3.ChildCellProperty(locked=True, doc="the bend")

    def _default_trace_template(self):
        tpl = SiNRibWaveguideTemplate_780nm()
        tpl.Layout(core_width=0.63, cladding_width=1)
        return tpl


    def _default_trace_template_wide(self):
        tpl = SiNRibWaveguideTemplate_780nm()
        tpl.Layout(core_width=0.63, cladding_width=21)
        return tpl
    # def _default_trace_template_wide(self):
    #     return SiNRibWaveguideTemplate_780nm()


    def _default_waveguide(self):
        return i3.RoundedWaveguide(trace_template=self.trace_template)


    def _default_slab(self):
        points = list(zip(X, Y))
        points.extend([ (end_EC, Slab_width), (starting_EC, Slab_width), (starting_EC, initial_gap)])
        return Slab(points=points)

    def _default_bend_waveguide(self):
        return i3.RoundedWaveguide(trace_template=self.trace_template_wide)

    def _default_grating_coupler(self):
    	return GRATING_COUPLER_TE780_RIBY()


    class Layout(i3.LayoutView):
        layer = i3.LayerProperty(default=asp.TECH.PPLAYER.RWG.CORE, doc='Layer to drawn on')
        waveguide_cladding_layer = i3.LayerProperty(default=i3.TECH.PPLAYER.RWG.CLADDING, doc="the optical waveguide cladding layer")
        #waveguide_length = i3.PositiveNumberProperty(default=EC_length, doc="the length of the waveguide")
        bend_radius = i3.PositiveNumberProperty(default=200.0)


        def _default_waveguide(self):
            cell_layout = self.cell.waveguide.get_default_view(i3.LayoutView)
            shape = [(waveguide_start, -waveguide_width/2), (waveguide_end, -waveguide_width/2)]
            cell_layout.set(shape=shape)
            return cell_layout


        def _default_bend_waveguide(self):
            cell_layout = self.cell.bend_waveguide.get_default_view(i3.LayoutView)
            cell_layout.bend_radius = self.bend_radius


            link_shape = i3.Shape([
                bend_start,
                (bend_start [0] + 200, bend_start[1]),
                (bend_start[0] + 200, bend_end[1]),
                bend_end
            ])
            cell_layout.set(shape=link_shape, bend_radius=self.bend_radius)
            return cell_layout



        def _generate_instances(self, insts):

            insts += i3.SRef(name='bus_waveguide', reference=self.cell.waveguide, position=(0, 0))
            insts += i3.SRef(name='bend_waveguide', reference=self.cell.bend_waveguide, position=(0,0))
            insts += i3.SRef(name='slab', reference=self.cell.slab, position=(0, 0))

            return insts



        def _generate_ports(self, ports):

                return i3.expose_ports(
                    self.instances,
                    {
                        "bus_waveguide:in": "in",
                        "bend_waveguide:out": "out",
                    },
                )
            #return ports


EC_layout = Structure_300_15().Layout()
EC_layout.visualize(annotate=True)
EC_layout.write_gdsii("EC.gds")