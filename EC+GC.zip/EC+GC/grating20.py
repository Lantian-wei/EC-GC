import asp_sin_lnoi_photonics.technology as TECH
import ipkiss3.all as i3                    # i3 is an alias for ipkiss3.all

import matplotlib.pyplot as plt
import numpy as np
file_path_A = r'C:\Users\Administrator\PyCharmMiscProject\grating-ipkiss20.txt'

def read_data(file_path):
    x_values = []
    y_values = []
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            parts = line.split(',')
            if len(parts) == 2:
                try:
                    x = float(parts[0].strip())
                    y = float(parts[1].strip())
                    x_values.append(x)
                    y_values.append(y)
                except ValueError:
                    continue
    return x_values, y_values

x_data, y_data= read_data(file_path_A)

def sub_grating(x):
    y=x*0.38
    return y

def sub_grating_ff(x):
    y = 0.86 - 0.02 * x
    if y < 0.14:
       y= 0.14
    return y

sub_ff=[sub_grating_ff(x) for x in range(41) for _ in range(40)]
sub_nonff=[1-sub_grating_ff(x) for x in range(41) for _ in range(40)]
sub_gratings=[sub_grating(x) for x in sub_ff]
sub_etching=[sub_grating(x) for x in sub_nonff]


etching=x_data
position=y_data


class GC20(i3.PCell):
    class Layout(i3.LayoutView):
        layer = i3.LayerProperty(default=i3.TECH.PPLAYER.WG.CORE, doc='Layer to drawn on')
        #rotation = i3.Rotation(rotation_center=(0.0, 0.0), rotation=11.0)
        #translation = i3.Translation(translation=(2500, 1))

        def _generate_elements(self, elems):
            for idx, (x, y,z) in enumerate(zip(etching, position, sub_etching)):
                #row
                polygon1 = i3.Shape([(y, 0), (y, z), (y+x, z), (y+x, 0)])
                elems += i3.Boundary(layer=self.layer, shape=polygon1)

                #column
                for j in range(1450):
                    polygon2 = i3.Shape([(y, 0.38*(j+1)), (y, z+0.38*(j+1)), (y+x, z+0.38*(j+1)), (y+x, 0.38*(j+1))])
                    elems += i3.Boundary(layer=self.layer, shape=polygon2)
                    #elems = elems.transform(self.rotation + self.translation)
            return elems


GC_layout = GC20().Layout(layer=i3.TECH.PPLAYER.WG.CORE)
GC_layout.visualize()
GC_layout.write_gdsii("grating.gds")

