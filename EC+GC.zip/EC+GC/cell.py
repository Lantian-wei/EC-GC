import sys
#sys.path.append('C:/Users/Administrator/OneDrive - RMIT University/Simulation & Design Projects/IPKISS/2024/July/SiN_LN_fab1/gc_780nm')
sys.path.append('C:/Users/Administrator/PycharmProjects/asp_sin_lnoi_photonics/ipkiss')

import asp_sin_lnoi_photonics.technology

import ipkiss3.all as i3
from picazzo3.fibcoup.curved import FiberCouplerCurvedGrating
from picazzo3.fibcoup.uniform import UniformLineGrating
from asp_sin_lnoi_photonics.components.waveguides.rib.trace_780nm import RWG600_780nm, SiNRibWaveguideTemplate_780nm

from ipkiss.technology import get_technology
from numpy import exp, sqrt

__all__ = ["GRATING_COUPLER_TE780_RIBY", "STRAIGHT_GRATING_COUPLER_TE780_RIBY", "GratingCouplerTE780RibY", "StraightGratingCouplerTE780RibY",
           "GRATING_COUPLER_TE780_RIBZ", "STRAIGHT_GRATING_COUPLER_TE780_RIBZ", "GratingCouplerTE780RibZ", "StraightGratingCouplerTE780RibZ"]

TECH = get_technology()


class SimpleGratingCouplerModel(i3.CompactModel):
    parameters = [
        'center_wavelength',
        'bandwidth_3dB',
        'peak_transmission',
        'reflection',
        'reflection_vertical_in',
    ]

    terms = [
        i3.OpticalTerm(name='vertical_in'),
        i3.OpticalTerm(name='out'),
    ]

    def calculate_smatrix(params, env, S):
        sigma = params.bandwidth_3dB / 2.35482  # fwhm => sigma
        power_S = params.peak_transmission * exp(
            -(env.wavelength - params.center_wavelength) ** 2.0 / (2.0 * (sigma ** 2.0)))

        S['vertical_in', 'out'] = S['out', 'vertical_in'] = sqrt(power_S)  # power=>amplitude
        S['out', 'out'] = params.reflection
        S['vertical_in', 'vertical_in'] = params.reflection_vertical_in


class _GratingCouplerTE780Y(FiberCouplerCurvedGrating):
    """
    Base class for focussing grating couplers
    """

    wvg_width_at_center = i3.PositiveNumberProperty(default=7.65 * 2)

    class Layout(FiberCouplerCurvedGrating.Layout):
        def _default_focal_distance_x(self):
            return 30

        def _default_min_x(self):
            return 21.735

        def _default_n_o_lines(self):
            return 40

        def _default_period_x(self):
            return 0.435

        def _default_period_y(self):
            return 0.3816271

        def _default_box_width(self):
            return 24

        def _default_fill_factor(self):
            return 0.6

        def _default_start_radius_y(self):
            return self.min_x * self.period_y / self.period_x

    class CircuitModel(FiberCouplerCurvedGrating.CircuitModel):
        def _default_center_wavelength(self): return 0.775

        def _default_bandwidth_3dB(self): return 0.060  # TBD

        def _default_peak_transmission(self): return 0.3  # from simulation

        def _default_reflection(self): return 0.1

        def _default_reflection_vertical_in(self): return 0.0

        def _generate_model(self):
            return SimpleGratingCouplerModel(center_wavelength=self.center_wavelength,
                                             bandwidth_3dB=self.bandwidth_3dB,
                                             peak_transmission=self.peak_transmission,
                                             reflection=self.reflection,
                                             reflection_vertical_in=self.reflection_vertical_in)


class _GratingCouplerTE780Z(FiberCouplerCurvedGrating):
    """
    Base class for focussing grating couplers
    """

    wvg_width_at_center = i3.PositiveNumberProperty(default=7.65 * 2)

    class Layout(FiberCouplerCurvedGrating.Layout):
        def _default_focal_distance_x(self):
            return 30

        def _default_min_x(self):
            return 21.735

        def _default_n_o_lines(self):
            return 40

        def _default_period_x(self):
            return 0.435  # not optimised

        def _default_period_y(self):
            return 0.3816271

        def _default_box_width(self):
            return 24

        def _default_fill_factor(self):
            return 0.75

        def _default_start_radius_y(self):
            return self.min_x * self.period_y / self.period_x

    class CircuitModel(FiberCouplerCurvedGrating.CircuitModel):
        def _default_center_wavelength(self): return 0.775

        def _default_bandwidth_3dB(self): return 0.060  # TBD

        def _default_peak_transmission(self): return 0.3  # from simulation

        def _default_reflection(self): return 0.1

        def _default_reflection_vertical_in(self): return 0.0

        def _generate_model(self):
            return SimpleGratingCouplerModel(center_wavelength=self.center_wavelength,
                                             bandwidth_3dB=self.bandwidth_3dB,
                                             peak_transmission=self.peak_transmission,
                                             reflection=self.reflection,
                                             reflection_vertical_in=self.reflection_vertical_in)



class GratingCouplerTE780RibY(_GratingCouplerTE780Y):
    _name_prefix = 'fiber_grating_coupler_te_780_ribY'
    cladding_width = i3.PositiveNumberProperty(default=TECH.RWG.CLADDING_WIDTH)
    start_wvg_width = i3.PositiveNumberProperty(default=TECH.RWG.RIB_WIDTH)

    def _default_start_trace_template(self):
        start_wg_tmpl = RWG600_780nm()
        return start_wg_tmpl

    def _default_wide_trace_template(self):
        end_wg_tmpl = SiNRibWaveguideTemplate_780nm(name=self.name + "_wgt_w")
        end_wg_tmpl.Layout(core_width=self.wvg_width_at_center,
                           cladding_width=self.cladding_width + self.wvg_width_at_center)
        return end_wg_tmpl



class GratingCouplerTE780RibZ(_GratingCouplerTE780Z):
    _name_prefix = 'fiber_grating_coupler_te_780_ribZ'
    cladding_width = i3.PositiveNumberProperty(default=TECH.RWG.CLADDING_WIDTH)
    start_wvg_width = i3.PositiveNumberProperty(default=TECH.RWG.RIB_WIDTH)

    def _default_start_trace_template(self):
        start_wg_tmpl = RWG600_780nm()
        return start_wg_tmpl

    def _default_wide_trace_template(self):
        end_wg_tmpl = SiNRibWaveguideTemplate_780nm(name=self.name + "_wgt_w")
        end_wg_tmpl.Layout(core_width=self.wvg_width_at_center,
                           cladding_width=self.cladding_width + self.wvg_width_at_center)
        return end_wg_tmpl

@i3.lock_properties()
class GRATING_COUPLER_TE780_RIBY(GratingCouplerTE780RibY):
    def _default_name(self):
        return "GCTE780RIBY"

class GRATING_COUPLER_TE780_RIBZ(GratingCouplerTE780RibZ):
    def _default_name(self):
        return "GCTE780RIBZ"


# straight GC
class _StraightGratingCouplerTE780Y(UniformLineGrating):
    """
    Base class for straight grating couplers
    """

    class Layout(UniformLineGrating.Layout):
        def _default_origin(self):
            return (0.0, 0.0)

        def _default_period(self):
            return 0.435

        def _default_line_width(self):
            return 0.435 * 0.75

        def _default_line_length(self):
            return 20.0

        def _default_n_o_periods(self):
            return 40

        def _default_socket_length(self):
            return 50.0

class _StraightGratingCouplerTE780Z(UniformLineGrating):
    """
    Base class for straight grating couplers
    """

    class Layout(UniformLineGrating.Layout):
        def _default_origin(self):
            return (0.0, 0.0)

        def _default_period(self):
            return 0.435  # not optimised

        def _default_line_width(self):
            return 0.435 * 0.75

        def _default_line_length(self):
            return 20.0

        def _default_n_o_periods(self):
            return 40

        def _default_socket_length(self):
            return 50.0


class StraightGratingCouplerTE780RibY(_StraightGratingCouplerTE780Y):
    _name_prefix = 'straight_fiber_grating_coupler_te_rib_Y'

    def _default_trace_template(self):
        wg_t = SiNRibWaveguideTemplate_780nm(name=self.name + "wgt")
        wg_t.Layout(core_width=10.0, cladding_width=20.0)
        return wg_t

class StraightGratingCouplerTE780RibZ(_StraightGratingCouplerTE780Z):
    _name_prefix = 'straight_fiber_grating_coupler_te_rib_Z'

    def _default_trace_template(self):
        wg_t = SiNRibWaveguideTemplate_780nm(name=self.name + "wgt")
        wg_t.Layout(core_width=10.0, cladding_width=20.0)
        return wg_t


@i3.lock_properties()
class STRAIGHT_GRATING_COUPLER_TE780_RIBY(StraightGratingCouplerTE780RibY):
    def _default_name(self):
        return "SGCTE780RIBY"

class STRAIGHT_GRATING_COUPLER_TE780_RIBZ(StraightGratingCouplerTE780RibZ):
    def _default_name(self):
        return "SGCTE780RIBZ"


