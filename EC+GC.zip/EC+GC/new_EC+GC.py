import ipkiss3.all as i3
import asp_sin_lnoi_photonics.all as asp
from grating5 import GC5
from grating10 import GC10
from grating15 import GC15
from grating20 import GC20
from device_250_5 import EC250_5
from device_250_10 import EC250_10
from device_250_15 import EC250_15
from device_250_20 import EC250_20
from device_300_5 import EC300_5
from device_300_10 import EC300_10
from device_300_15 import EC300_15
from device_300_20 import EC300_20

import math

ec250_5=EC250_5()
ec250_10=EC250_10()
ec250_15=EC250_15()
ec250_20=EC250_20()
ec300_5=EC300_5()
ec300_10=EC300_10()
ec300_15=EC300_15()
ec300_20=EC300_20()
gc5 = GC5()
gc10 = GC10()
gc15 = GC15()
gc20 = GC20()


ebl_writing_size = (1000, 1000)
chip_elements = list()
# 1. grid
grid = asp.FRAME_13000_10000_WITH_EBL_GRID()
grid_lo = grid.Layout(ebl_writing_size=ebl_writing_size)
chip_elements.append(i3.SRef(reference=grid, position=(0.0, 0.0)))
chip_elements.append(i3.SRef(reference=grid, position=(0.0, 0.0)))

test_site = i3.Circuit(
    insts={"ec1": ec250_5,"ec2": ec250_5,"ec3": ec250_10,"ec4": ec250_10,
           "ec5": ec250_15,"ec6": ec250_15,"ec7": ec250_20,"ec8": ec250_20,"ec9": ec300_5,
           "ec10": ec300_5,"ec11": ec300_10,"ec12": ec300_15,"ec13": ec300_20,
           "gc1": gc5, "gc2": gc10,"gc3": gc10,"gc4": gc15,
           "gc5": gc15, "gc6": gc20,"gc7": gc20,"gc8": gc5,
           "gc9": gc10, "gc10": gc15,"gc11": gc20,
           "gc12": gc5,"gc13": gc5, "gc14": gc10,"gc15": gc10,
            "gc16": gc15, "gc17": gc15, "gc18": gc20, "gc19": gc20,
           },

    specs=[
        i3.Place("ec1", (-4600, 4000.0), 0),
        i3.Place("ec2", (-4600, 2650.0), 0),
        i3.Place("ec3", (-4600, 1300.0), 0),
        i3.Place("ec4", (-4600, -50.0), 0),
        i3.Place("ec5", (-4600, -1400.0), 0),
        i3.Place("ec6", (-4600, -2750.0), 0),
        i3.Place("ec7", (-4600, -4200.0), 0),
        i3.Place("ec8", (0, 3900.0), 0),
        i3.Place("ec9", (0, 2400.0), 0),
        i3.Place("ec10", (0, 900.0), 0),
        i3.Place("ec11", (0, -700.0), 0),
        i3.Place("ec12", (0, -2300.0), 0),
        i3.Place("ec13", (0, -3900.0), 0),

        i3.Place("gc1", (-4600+2500, 2650+1), 11),
        i3.Place("gc2", (-4600+2500, 1300+1), 11),
        i3.Place("gc3", (-4600+2500, -50+1), 11),
        i3.Place("gc4", (-4600+2500, -1400+1), 11),
        i3.Place("gc5", (-4600+2500, -2750+1), 11),
        i3.Place("gc6", (-4600+2500, -4200+1), 11),
        i3.Place("gc7", (0+2500, 3900+1), 11),

        i3.Place("gc8", (0+3100, 900+1), 11),
        i3.Place("gc9", (0+3100, -700+1), 11),
        i3.Place("gc10", (0+3100, -2300+1), 11),
        i3.Place("gc11", (0+3100, -3900+1), 11),
        i3.Place("gc12", (4500, 3500), 0),
        i3.Place("gc13", (5000, 3500), 0),
        i3.Place("gc14", (4500, 2500), 0),
        i3.Place("gc15", (4500, 1500), 0),
        i3.Place("gc16", (4500, 500), 0),
        i3.Place("gc17", (4500, -500), 0),
        i3.Place("gc18", (4500, -1500), 0),
        i3.Place("gc19", (4500, -2500), 0),

    ],
)


ring_test_layout = test_site.Layout()
ring_test_layout.visualize(annotate=True)
ring_test_layout.write_gdsii("EC+GC.gds")
